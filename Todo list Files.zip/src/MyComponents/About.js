import React from 'react'

export const About = () => {
    return (
        <div>
            This is an About components.
            <p>Lorem 34sg;jngvdolvnd'fbdfbnvw/lgnsglsngSnd/lkns/glkdndhgs,mnd;godjdsbg;adgns'oignsddnv;obofbnfbndbhdnbdlknsblnbdljdng'o</p>
        </div>
    )
}
